#ifndef PACKET_H
#define PACKET_H

#include <cstdint>   // Para tipos como uint8_t
#include <ws2tcpip.h> // Para in6_addr (IPv6) en Windows
#include <QString>   // Necesario para QString

class Packet
{
public:
    // Constructores y destructor
    Packet();
    Packet(int, int, int, int);
    ~Packet();

    int id; // id del paquete en la lista de paquetes
    int opc; // verificaremos si es para ipv4 o ipv6
    int size_packet; // tamaño del paquete con cabecera
    int size_data; // tamaño del paquete sin cabecera

    char* raw_data = nullptr; // Puntero que apunta a los datos del raw del paquete

    Packet* next_packet = nullptr; // Puntero para lista enlazada

    // Estructura de IPv4
    struct IPv4
    {
        uint8_t ip_vhl;  // Versión y longitud del encabezado (4 bits cada uno)
        uint8_t ip_tos;  // Tipo de servicio
        uint16_t ip_len; // Longitud total (encabezado + datos)
        uint16_t ip_id;  // Identificación
        uint16_t ip_off; // Flags y fragment offset
        uint8_t ip_ttl;  // Tiempo de vida (TTL)
        uint8_t ip_p;    // Protocolo (TCP, UDP, ICMP, etc.)
        uint16_t ip_sum; // Suma de verificación del encabezado
        uint32_t ip_src; // Dirección IP de origen
        uint32_t ip_dst; // Dirección IP de destino
    };

    // Estructura de IPv6
    struct IPv6
    {
        uint32_t ip_vtc_flow;   // Versión (4 bits), Traffic Class (8 bits), Flow Label (20 bits)
        uint16_t ip_len;        // Payload Length
        uint8_t ip_nh;          // Next Header (similar a protocolo en IPv4)
        uint8_t ip_hlim;        // Hop Limit (similar a TTL en IPv4)
        struct in6_addr ip_src; // Dirección IPv6 de origen
        struct in6_addr ip_dst; // Dirección IPv6 de destino
    };

    // Unión para encapsular IPv4 e IPv6
    union IPvType
    {
        IPv4* ipv4 = nullptr;
        IPv6* ipv6;
    } ip_data;

    // Métodos ----------------------

    // Getters ---------------
    int getId();
    int getOpc();
    int getSize_packet();
    int getSize_data();
    const char* getRawData() const;
    QString getRawDataHex() const;
    QString getRawDataCSV() const;

    // Getters para IPv4
    QString getIPv4Version() const;
    QString getIPv4HeaderLength() const;
    QString getIPv4Source() const;
    QString getIPv4Destination() const;
    QString getIPv4Protocol() const;
    QString getIPv4TTL() const;
    QString getIPv4Checksum() const;
    QString getIPv4TotalLength() const;
    QString getIPv4Identification() const;

    // Getters para IPv6
    QString getIPv6PayloadLength() const;
    QString getIPv6Source() const;
    QString getIPv6Destination() const;
    QString getIPv6Protocol() const;
    QString getIPv6HopLimit() const;
    QString getIPv6Version() const;

    // Métodos adicionales
    QString getPacketDetails(); // Para obtener todos los detalles de la trama en un QString

    // Setters ---------------
    void setId(int);
    void setOpc(int);
    void setSize_packet(int);
    void setSize_data(int);
    void setRawData(const u_char*, int);

    // Setters para asignar los structs completos (IPv4 o IPv6)
    void setIPv4Data(const IPv4& ipv4_data);
    void setIPv6Data(const IPv6& ipv6_data);

    // Setter para elegir el tipo de IP (IPv4 o IPv6)
    void setIPType(bool is_ipv4); // `true` para IPv4, `false` para IPv6
};

#endif // PACKET_H
