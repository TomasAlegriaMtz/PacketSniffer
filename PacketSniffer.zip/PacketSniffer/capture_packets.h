#ifndef CAPTURE_PACKETS_H
#define CAPTURE_PACKETS_H

#include <QThread>
#include <pcap.h>
#include <QDebug>
#include <QMutex>
#include "packet.h"
#include "packets_window.h"
#include <QDialog>

#include <QFile>
#include <QTextStream>

class capture_packets : public QThread
{
    Q_OBJECT

public:
    // Constructor con la lista compartida y el mutex para el acceso
    capture_packets(QList<Packet *> *packetList, QMutex *mtx, packets_window *window, QObject *parent = nullptr);

    void captura();  // Método que captura los paquetes
    void apertura_disp();  // Método que abre el dispositivo de captura
    void call_me(u_char *, const struct pcap_pkthdr *, const u_char *);  // Callback para manejar paquetes
    void add_list(Packet *packet);  // Método para agregar paquetes a la lista

    void onFilter_applied(QString filter);
    void start_capturing();
    void onsaving_applied(bool band);
    void initializeFiles();
    void disp_list();


    QFile csvFile;
    QTextStream csvStream;


protected:
    void run() override;

private:
    QList<Packet *> *list_packets;  // Lista de paquetes compartida
    QMutex *mutex;  // Mutex para sincronizar el acceso a la lista de paquetes
    packets_window *window;
    bool flag = false;

    bool savingEnabled; // Indica si se deben guardar los datos

};

#endif // CAPTURE_PACKETS_H
