#ifndef PACKETS_WINDOW_H
#define PACKETS_WINDOW_H

#include <QDialog>
#include <QMutex>
#include <QTableWidget>
#include <QList>
#include <QMessageBox>
#include <QCloseEvent>
#include <QFile>
#include <QTextStream>
#include <QTime>
#include "packet.h"
#include <QFileDialog>


namespace Ui {
class packets_window;
}

class packets_window : public QDialog
{
    Q_OBJECT

public:
    explicit packets_window(QList<Packet *> *, QWidget *parent = nullptr);
    ~packets_window();

    void addPacketToTable(int , const QString , const QString &,
                          const QString &, const QString &, int, int);

    void addRawPacket(QString);
    QColor getProtocolColor(const QString &, bool );
    void addPacketDetails(QString);


    //static void addDevices(QString device);
    static QList<QString> deviceslist;
    static int selectedDeviceIndex;

signals:
    void packetSelected(int ); // Señal que emite el número del paquete seleccionado
    void filter_applied(QString ); // Señal que emite cuando se da enter a el filtro
    void start_capturing();
    void saving_applied(bool);//señal que emite cuando se da click para salvar el trafico

private slots:
    void onCellClicked(int , int ); // Slot para manejar el clic en la tabla
    void onButtonClicked();
    void onsavingButtonClicked();
    void onComboBoxSelectionChanged();

    void on_listDevices_itemSelectionChanged();
    void on_listProtocol_itemSelectionChanged();
    void on_comboIP_activated(int index);
    void on_checkIPSource_stateChanged(int arg1);
    void on_checkIPDest_stateChanged(int arg1);
    void on_checkIPSubnet_stateChanged(int arg1);
    void on_bBegin_clicked();


    void on_pushButton_clicked();

private:
    QString global_filter = "";
    Ui::packets_window *ui;
    bool band;
    QString appliedFilter;
    QList<Packet *> *list_packets;

    QFile csvFile;
    QTextStream csvStream;


    void fillDeviceList();
    void saveAllPackets();
protected:
    void closeEvent(QCloseEvent *) override;
};

#endif // PACKETS_WINDOW_H
