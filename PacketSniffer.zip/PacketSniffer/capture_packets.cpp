#include "capture_packets.h"
#include "resources.hpp"
#include <QString>
#include <QHostAddress>
#include <QMutexLocker>
#include <QFile>
#include <QTextStream>
#include <QDir>
#include "packets_window.h"
#include <QFileDialog> // Necesario para el QFileDialog



pcap_if_t *all_devices = nullptr;
pcap_if_t *device = nullptr;
pcap_if_t *open_dev = nullptr;
pcap_t *cap_dev = nullptr;

int link_hdr_length = 0;
int num_disp = 0;
static int packet_counter = 0; // Contador para el número de paquete

char error_buffer[PCAP_ERRBUF_SIZE] = {0};


// Constructor que recibe la lista compartida y el mutex
capture_packets::capture_packets(QList<Packet *> *packetList, QMutex *mtx, packets_window *window, QObject *parent)
    : QThread(parent), list_packets(packetList), mutex(mtx), window(window) {
    connect(window, &packets_window::filter_applied, this, &capture_packets::onFilter_applied);
    connect(window, &packets_window::start_capturing, this, &capture_packets::start_capturing);
    connect(window, &packets_window::saving_applied, this, &capture_packets::onsaving_applied);

}

//emitira una senial a esta funcion que activa la bandera para que se ingrese el dispositivo
// y a su vez se seleccionara el dispositivo que se desea
void capture_packets::start_capturing(){
    // guardaremos hasta la opcion que fue elegida
    for (int i = 0; i < packets_window::selectedDeviceIndex; i++)
    {
        device = device->next;
        //qDebug() << device->description << "\n";
    }

    qDebug()<<device->description;

    cap_dev = pcap_open_live(device->name, BUFSIZ, 1, -1, error_buffer);
    if (cap_dev == nullptr) {
        qDebug() << "Error opening device:" << error_buffer;
        return; // Salir para evitar un crash
    }

    // Verificar el tipo de enlace y definir cuántos bytes debe saltar para la cabecera
    switch (pcap_datalink(cap_dev))
    {
    // Loopback
    case DLT_NULL:
        link_hdr_length = 4;
        break;
    // Ethernet
    case DLT_EN10MB:
        link_hdr_length = 14;
        break;
    default:
        link_hdr_length = 0;
    }
    this->flag = true;
}

void capture_packets::run()
{
    this->apertura_disp();

    do {
        this->captura();
    } while (true);
}
/*
void capture_packets::disp_list(){
    pcap_findalldevs(&all_devices, error_buffer);

    qDebug() << "Available devices:" << "\n";
    qDebug() << "Select device ..." << "\n";
    for (device = all_devices; device != NULL; device = device->next)
    {
        qDebug() << ++num_disp << ". ";
        if (device->description)
        {
            qDebug() << device->description;
            listDevices

        }
        qDebug() << "\n";
    }

}*/

void capture_packets::apertura_disp(){
    pcap_findalldevs(&all_devices, error_buffer);

    qDebug() << "Available devices:" << "\n";
    qDebug() << "Select device ..." << "\n";
    for (device = all_devices; device != NULL; device = device->next)
    {
        qDebug() << ++num_disp << ". ";
        if (device->description)
        {
            qDebug() << device->description;
            packets_window::deviceslist.append(device->description);

        }
        qDebug() << "\n";
    }

    device = all_devices;
    while(!this->flag){}
}

void capture_packets::captura()
{
    struct pcap_pkthdr *header;

    const u_char *packet;
    int result = pcap_next_ex(cap_dev, &header, &packet);
    if (result == 1)
    { // Paquete capturado
        call_me(NULL, header, packet);
    }
}

/* Esta funcion será utilizada como una función de devolución de llamada (callback)
   para procesar los paquetes capturados por libpcap o Npcap. Esta función es pasada a
   pcap_loop o funciones similares para que se ejecute cada vez que se captura un paquete. */
void capture_packets::call_me(u_char *user, const struct pcap_pkthdr *pkthdr, const u_char *packetd_ptr)
{
    packetd_ptr += link_hdr_length; // Desplazar el puntero para omitir la cabecera de enlace
    uint8_t ip_version = (*packetd_ptr) >> 4; // Los primeros 4 bits indican la versión del protocolo IP

    int opc = (ip_version == 4) ? 1 : (ip_version == 6) ? 2 : 0; // Usamos ternario para decidir si es IPv4 o IPv6

    if (ip_version == 4 || ip_version == 6) { // Solo si es IPv4 o IPv6
        int id = ++packet_counter;  // Incrementar el contador antes para el id del paquete
        int packet_size = pkthdr->len;  // Tamaño total del paquete (incluyendo la cabecera)
        int data_size = packet_size - link_hdr_length;  // Tamaño de los datos crudos

        // Crear un nuevo objeto Packet con los valores de control
        Packet* packet = new Packet(id, opc, packet_size, data_size);

        // Establecer los datos crudos del paquete
        packet->setRawData(packetd_ptr, data_size);

        if (ip_version == 4) {
            // Procesar el paquete IPv4
            Packet::IPv4 ipv4_data;

            // Copiar la información de IPv4
            ipv4_data.ip_vhl = packetd_ptr[0];
            ipv4_data.ip_tos = packetd_ptr[1];
            ipv4_data.ip_len = ntohs(*(reinterpret_cast<const uint16_t*>(&packetd_ptr[2])));
            ipv4_data.ip_id = ntohs(*(reinterpret_cast<const uint16_t*>(&packetd_ptr[4])));
            ipv4_data.ip_off = ntohs(*(reinterpret_cast<const uint16_t*>(&packetd_ptr[6])));
            ipv4_data.ip_ttl = packetd_ptr[8];
            ipv4_data.ip_p = packetd_ptr[9];
            ipv4_data.ip_sum = ntohs(*(reinterpret_cast<const uint16_t*>(&packetd_ptr[10])));
            ipv4_data.ip_src = ntohl(*(reinterpret_cast<const uint32_t*>(&packetd_ptr[12])));
            ipv4_data.ip_dst = ntohl(*(reinterpret_cast<const uint32_t*>(&packetd_ptr[16])));

            // Asignar los datos IPv4 al paquete
            packet->setIPv4Data(ipv4_data);

        } else if (ip_version == 6) {
            // Procesar el paquete IPv6
            Packet::IPv6 ipv6_data;

            // Copiar la información de IPv6
            ipv6_data.ip_vtc_flow = ntohl(*(reinterpret_cast<const uint32_t*>(&packetd_ptr[0])));
            ipv6_data.ip_len = ntohs(*(reinterpret_cast<const uint16_t*>(&packetd_ptr[4])));
            ipv6_data.ip_nh = packetd_ptr[6];
            ipv6_data.ip_hlim = packetd_ptr[7];

            // Copiar las direcciones IPv6 de origen y destino
            memcpy(&ipv6_data.ip_src, &packetd_ptr[8], sizeof(struct in6_addr));
            memcpy(&ipv6_data.ip_dst, &packetd_ptr[24], sizeof(struct in6_addr));

            // Asignar los datos IPv6 al paquete
            packet->setIPv6Data(ipv6_data);
        }

        if (ip_version == 4 || ip_version == 6) {
            // Después de procesar el paquete, agregarlo a la lista de paquetes
            add_list(packet);  // Llamamos a la función que agrega el paquete a la lista

            // Guardar en el archivo CSV
            if (savingEnabled && csvFile.isOpen()) {
                //qDebug() << "Si entro" << packet->getId();
                QString src, dst, protocol;

                if (packet->getOpc() == 4) { // IPv4
                    src = packet->getIPv4Source();
                    dst = packet->getIPv4Destination();
                    protocol = "IPv4";
                } else if (packet->getOpc() == 6) { // IPv6
                    src = packet->getIPv6Source();
                    dst = packet->getIPv6Destination();
                    protocol = "IPv6";
                }

                // Escribir los datos del paquete en el archivo CSV
                csvStream << packet->getId() << ","
                          << src << ","
                          << dst << ","
                          << protocol << ","
                          << packet->getSize_packet() << ","
                          << packet->getRawDataCSV() << "\n";  // Guardamos los datos crudos en formato hexadecimal
                csvStream.flush();  // Forzar la escritura en disco

            }

            qDebug() << "Packet Received << " << packet->getId() << " << " << packet->getIPv4Source();
        }
    }
}


void capture_packets::add_list(Packet *new_packet)
{
    if (mutex) {
        QMutexLocker locker(mutex);  // Bloquear el mutex para asegurar acceso sincronizado
        if (list_packets) {
            list_packets->append(new_packet);  // Usamos append para agregar el paquete a la lista
        }
    }
}


void capture_packets::onFilter_applied(QString filter)
{
    qDebug() << "Filter applied:" << filter;

    // Convertir el filtro de QString a char*
    std::string filter_str = filter.toStdString();
    const char* filter_cstr = filter_str.c_str();

    // Si cap_dev no está abierto, no podemos aplicar un filtro
    if (!cap_dev) {
        qDebug() << "No capture device open!";
        return;
    }

    struct bpf_program fp;  // Estructura para almacenar el filtro compilado
    if (pcap_compile(cap_dev, &fp, filter_cstr, 0, PCAP_NETMASK_UNKNOWN) == -1) {
        qDebug() << "Error compiling filter: " << pcap_geterr(cap_dev);
        return;
    }

    // Aplicar el filtro al dispositivo de captura
    if (pcap_setfilter(cap_dev, &fp) == -1) {
        qDebug() << "Error applying filter: " << pcap_geterr(cap_dev);
        return;
    }

    qDebug() << "Filter applied successfully!";
}


//Señales de la clase window para guardar

void capture_packets::initializeFiles()
{
    // Limpiar los archivos existentes al inicio de la ejecución
    QDir dir = QDir::current();
    QStringList existingFiles = dir.entryList(QStringList() << "captured_packets_*.csv", QDir::Files);

    for (const QString &fileName : existingFiles) {
        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            file.close(); // Esto vacía el contenido del archivo
            qDebug() << "Cleared file from previous execution:" << fileName;
        }
    }
}
void capture_packets::onsaving_applied(bool band)
{
    // Almacena el estado de guardado
    savingEnabled = band;

    if (!band) {
        if (csvFile.isOpen()) {
            csvFile.close(); // Cerrar el archivo temporal
            qDebug() << "Guardado temporal de paquetes finalizado.";
        }

        QString fileName = QFileDialog::getSaveFileName(
            nullptr,
            "Guardar archivo CSV final",
            QDir::homePath() + "/captured_packets_final.csv",
            "Archivos CSV (*.csv)"
            );

        if (fileName.isEmpty()) {
            qDebug() << "Guardado final cancelado por el usuario.";
            return;
        }

        if (QFile::exists(fileName)) {
            QFile::remove(fileName);
        }

        bool success = QFile::rename(csvFile.fileName(), fileName);
        if (success) {
            qDebug() << "Archivo CSV final guardado como:" << fileName;
        } else {
            qWarning() << "Error al guardar el archivo final:" << csvFile.errorString();
        }
    }
    else
    {
        QString tempFileName = QString("captured_packets_%1.csv")
                                   .arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss"));

        csvFile.setFileName(tempFileName);
        if (csvFile.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Append)) {
            csvStream.setDevice(&csvFile);

            if (csvFile.size() == 0) {
                csvStream << "PacketNo,Source,Destination,Protocol,Length,Raw\n";
                qDebug() << "Encabezados agregados al archivo temporal:" << tempFileName;
            }
            qDebug() << "Archivo temporal creado para guardar paquetes:" << tempFileName;
        } else {
            qWarning() << "Error al crear el archivo temporal:" << csvFile.errorString();
        }
    }
}




