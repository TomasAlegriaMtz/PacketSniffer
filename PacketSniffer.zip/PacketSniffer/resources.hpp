#ifndef RESOURCES_HPP
#define RESOURCES_HPP

#include <wpcapi.h>
#include <stdint.h>
#include <pcap.h>
#include "packets_window.h"
#include <QString>
#include <QHostAddress>




// Declaramos el buffer de errores
extern char error_buffer[PCAP_ERRBUF_SIZE];

/* Capturamos todas las interfaces de tipo pcap_if_t que se encuentran en pcap.h */
extern pcap_if_t *all_devices;
extern pcap_if_t *device;
extern pcap_if_t *open_dev;
extern pcap_t *cap_dev;

extern int link_hdr_length;
extern int num_disp;




//FUNCIONES ----------------------------------------------------------------------------------------


#endif // RESOURCES_HPP
