#include "packet.h"
#include <QString>
#include <Winsock2.h>  // Para inet_ntoa (IPv4) y otras funciones útiles en Windows
#include <iostream> // Para poder imprimir si es necesario

// Constructores
Packet::Packet()
    : raw_data(nullptr), next_packet(nullptr), ip_data{nullptr} {}

Packet::Packet(int id, int opc, int size_packet, int size_data)
    :  raw_data(nullptr), next_packet(nullptr), ip_data{nullptr},
    id{id}, opc{opc}, size_packet{size_packet}, size_data{size_data} {}

// Destructor
Packet::~Packet()
{
    // Liberar memoria de raw_data si se asignó
    if (raw_data != nullptr)
    {
        delete[] raw_data;
    }

    // Liberar memoria para las estructuras IPv4 e IPv6 si están asignadas
    if (ip_data.ipv4 != nullptr)
    {
        delete ip_data.ipv4;
    }
    if (ip_data.ipv6 != nullptr)
    {
        delete ip_data.ipv6;
    }
}




//setters -------------------------------------------------------------------------

void Packet::setId(int id)
{
    this->id = id;
}

void Packet::setOpc(int opc)
{
    this->opc = opc;
}

void Packet::setSize_packet(int size_packet)
{
    this->size_packet = size_packet;
}

void Packet::setSize_data(int size_data){
    this->size_data = size_data;
}

void Packet::setRawData(const u_char* data, int data_size)
{
    raw_data = new char[data_size];
    memcpy(raw_data, data, data_size);
}


void Packet::setIPv4Data(const IPv4& ipv4_data)
{

    ip_data.ipv4 = new IPv4(ipv4_data);  // Copia profunda de los datos de IPv4
    opc = 4;  // Indicar que es IPv4
}


// Setter para IPv6
void Packet::setIPv6Data(const IPv6& ipv6_data)
{
    ip_data.ipv6 = new IPv6(ipv6_data);  // Asignamos una nueva estructura IPv6
    opc = 6;  // Indicamos que es IPv6
}

// Setter para elegir el tipo de IP (IPv4 o IPv6)
void Packet::setIPType(bool is_ipv4)
{
    if (is_ipv4)
    {
        opc = 4;  // IPv4
    }
    else
    {
        opc = 6;  // IPv6
    }
}


//Getters --------------------------------------------------------------------------------
int Packet::getId()
{
    return this->id;
}

int Packet::getOpc()
{
    return this->opc;
}

int Packet::getSize_packet()
{
    return this->size_packet;
}

int Packet::getSize_data()
{
    return this->size_data;
}

const char* Packet::getRawData() const
{
    return raw_data;  // Devolver el puntero a los datos crudos
}

QString Packet::getRawDataHex() const {
    QString hexString;
    const unsigned char *data = reinterpret_cast<const unsigned char *>(this->raw_data); // rawData es la variable que contiene los datos crudos

    for (int i = 0; i < this->size_data; ++i) {  // rawDataSize es el tamaño de los datos crudos
        hexString.append(QString::asprintf("%02X ", data[i]));

        // Agregar un salto de línea cada 16 bytes
        if ((i + 1) % 16 == 0) {
            hexString.append("\n");
        }
    }

    return hexString;
}


QString Packet::getRawDataCSV() const {
    QString hexString;
    const unsigned char *data = reinterpret_cast<const unsigned char *>(this->raw_data); // rawData es la variable que contiene los datos crudos

    for (int i = 0; i < this->size_data; ++i) {  // rawDataSize es el tamaño de los datos crudos
        hexString.append(QString::asprintf("%02X ", data[i]));
    }

    return hexString;
}



// Getters para IPv4
QString Packet::getIPv4Version() const
{
    return QString::number((ip_data.ipv4->ip_vhl >> 4) & 0x0F);  // Extraemos los 4 bits de la versión
}

QString Packet::getIPv4HeaderLength() const
{
    return QString::number(ip_data.ipv4->ip_vhl & 0x0F);  // Extraemos los 4 bits de longitud del encabezado
}

QString Packet::getIPv4Source() const
{
    struct in_addr addr;
    addr.s_addr = htonl(ip_data.ipv4->ip_src);  // Convertir explícitamente al orden de red
    //qDebug() << "Raw Source IP (host byte order):" << QString::number(ip_data.ipv4->ip_src, 16);
    //qDebug() << "Converted Source IP (inet_ntoa):" << QString(inet_ntoa(addr));

    return QString(inet_ntoa(addr));  // Convierte la dirección IPv4 a formato legible
}

QString Packet::getIPv4Destination() const
{
    struct in_addr addr;
    addr.s_addr = htonl(ip_data.ipv4->ip_dst);  // Convertir explícitamente al orden de red
    //qDebug() << "Raw Destination IP (host byte order):" << QString::number(ip_data.ipv4->ip_dst, 16);
    //qDebug() << "Converted Destination IP (inet_ntoa):" << QString(inet_ntoa(addr));

    return QString(inet_ntoa(addr));  // Convierte la dirección IPv4 a formato legible
}


QString Packet::getIPv4Protocol() const
{
    switch (ip_data.ipv4->ip_p)
    {
    case 0: return "Reserved";           // reservado
    case 1: return "ICMP";               // ICMP
    case 2: return "IGMP";               // IGMP
    case 6: return "TCP";                // TCP
    case 17: return "UDP";               // UDP
    case 41: return "IPv6 encapsulado";  // IPv6 en IPv4
    case 50: return "ESP";               // ESP (Encapsulating Security Payload)
    case 51: return "AH";                // AH (Authentication Header)
    case 58: return "ICMPv6";            // ICMPv6
    case 89: return "OSPF";              // OSPF (Open Shortest Path First)
    default: return QString::number(ip_data.ipv4->ip_p);  // Otros protocolos
    }
}

QString Packet::getIPv4TTL() const
{
    return QString::number(ip_data.ipv4->ip_ttl);
}

QString Packet::getIPv4Checksum() const
{
    return QString::number(ip_data.ipv4->ip_sum, 16);  // Suma de verificación en hexadecimal
}

QString Packet::getIPv4TotalLength() const
{
    return QString::number(ip_data.ipv4->ip_len);
}

QString Packet::getIPv4Identification() const
{
    return QString::number(ip_data.ipv4->ip_id);
}

// Getters para IPv6
QString Packet::getIPv6PayloadLength() const
{
    return QString::number(ip_data.ipv6->ip_len);
}

QString Packet::getIPv6Source() const
{
    char buffer[INET6_ADDRSTRLEN];
    inet_ntop(AF_INET6, &ip_data.ipv6->ip_src, buffer, INET6_ADDRSTRLEN);
    return QString(buffer);  // Convierte la dirección IPv6 a un formato legible
}

QString Packet::getIPv6Destination() const
{
    char buffer[INET6_ADDRSTRLEN];
    inet_ntop(AF_INET6, &ip_data.ipv6->ip_dst, buffer, INET6_ADDRSTRLEN);
    return QString(buffer);  // Convierte la dirección IPv6 a un formato legible
}


QString Packet::getIPv6Protocol() const
{
    switch (ip_data.ipv6->ip_nh)
    {
    case 0: return "Reserved";           // reservado
    case 1: return "ICMP";               // ICMP
    case 2: return "IGMP";               // IGMP
    case 6: return "TCP";                // TCP
    case 17: return "UDP";               // UDP
    case 58: return "ICMPv6";            // ICMPv6
    case 43: return "Routing Header";    // Routing Header
    case 44: return "Fragment Header";   // Fragment Header
    case 50: return "ESP";               // ESP (Encapsulating Security Payload)
    case 51: return "AH";                // AH (Authentication Header)
    default: return QString::number(ip_data.ipv6->ip_nh);  // Otros protocolos
    }
}


QString Packet::getIPv6HopLimit() const
{
    return QString::number(ip_data.ipv6->ip_hlim);
}

QString Packet::getIPv6Version() const
{
    return QString::number((ntohl(ip_data.ipv6->ip_vtc_flow) >> 28) & 0x0F);  // Extraemos los 4 bits de la versión
}


QString Packet::getPacketDetails()
{
    QString details;

    // Agregar detalles generales del paquete
    details += "ID del Paquete: " + QString::number(id) + "\n";
    details += "Tamaño del Paquete (con cabecera): " + QString::number(size_packet) + " bytes\n";
    details += "Tamaño de los Datos: " + QString::number(size_data) + " bytes\n";

    // Agregar detalles según el tipo de IP (IPv4 o IPv6)
    if (opc == 4 && ip_data.ipv4 != nullptr) {  // Si es IPv4
        details += "IPv4 Version: " + getIPv4Version() + "\n";
        details += "Longitud del Encabezado IPv4: " + getIPv4HeaderLength() + "\n";
        details += "Dirección de Origen IPv4: " + getIPv4Source() + "\n";
        details += "Dirección de Destino IPv4: " + getIPv4Destination() + "\n";
        details += "Protocolo IPv4: " + getIPv4Protocol() + "\n";
        details += "TTL IPv4: " + getIPv4TTL() + "\n";
        details += "Checksum IPv4: " + getIPv4Checksum() + "\n";
        details += "Longitud Total IPv4: " + getIPv4TotalLength() + "\n";
        details += "Identificación IPv4: " + getIPv4Identification() + "\n";

        // Datos de control IPv4
        details += "Flags IPv4: " + QString::number(ip_data.ipv4->ip_off >> 13) + "\n";  // Obtener los 3 bits de flags
        details += "Fragment Offset IPv4: " + QString::number(ip_data.ipv4->ip_off & 0x1FFF) + "\n"; // Fragment offset

    }
    else if (opc == 6 && ip_data.ipv6 != nullptr) {  // Si es IPv6
        details += "IPv6 Version: " + getIPv6Version() + "\n";
        details += "Longitud de Payload IPv6: " + getIPv6PayloadLength() + "\n";
        details += "Dirección de Origen IPv6: " + getIPv6Source() + "\n";
        details += "Dirección de Destino IPv6: " + getIPv6Destination() + "\n";
        details += "Protocolo IPv6: " + getIPv6Protocol() + "\n";
        details += "Hop Limit IPv6: " + getIPv6HopLimit() + "\n";

        // Más datos de control en IPv6
        details += "Flow Label IPv6: " + QString::number(ip_data.ipv6->ip_vtc_flow & 0xFFFFF) + "\n"; // 20 bits
        details += "Traffic Class IPv6: " + QString::number((ip_data.ipv6->ip_vtc_flow >> 20) & 0xFF) + "\n"; // 8 bits
    }

    return details;
}

