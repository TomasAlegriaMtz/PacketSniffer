#include "packets_window.h"
#include "capture_packets.h"
#include "print_packets.h"
#include <QApplication>
#include <QMutex>
#include <QDebug>
#include <QThread>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QMutex mutex;
    QList<Packet *> list_packets;

    // Crear la ventana de captura de paquetes
    packets_window *window = new packets_window(&list_packets);
    window->show();

    window->setWindowIcon(QIcon(":/iconos/wirejuan1.ico"));

    // Crear el hilo de captura y pasarle la lista de paquetes y el mutex
    capture_packets *thread_capture = new capture_packets(&list_packets, &mutex, window);
    thread_capture->start();

    // Crear el hilo de impresión y pasarle la lista de paquetes, la ventana y el mutex
    print_packets *thread_print = new print_packets(&list_packets, window, &mutex);
    thread_print->start();  // Inicia el hilo de impresión

    return a.exec();
}
