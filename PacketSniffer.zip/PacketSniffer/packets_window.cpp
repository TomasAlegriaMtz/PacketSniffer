#include "packets_window.h"
#include "ui_packets_window.h"
#include <QFileDialog> // Necesario para el QFileDialog

packets_window::packets_window(QList<Packet *> *list_packets, QWidget *parent)
    : list_packets(list_packets), QDialog(parent)
    , ui(new Ui::packets_window)
{
    ui->setupUi(this);
    ui->tabWidget->setCurrentIndex(0);  // Cambia al índice de la sección que deseas mostrar

    // Conectar los eventos
    connect(ui->table_packets, &QTableWidget::cellClicked, this, &packets_window::onCellClicked);
    //connect(ui->bBegin, &QPushButton::clicked, this, &packets_window::on_bBegin_clicked);

    connect(ui->apply_filter, &QPushButton::clicked, this, &packets_window::onButtonClicked);
    connect(ui->select_filter, &QComboBox::currentIndexChanged, this, &packets_window::onComboBoxSelectionChanged);

    //guardar datos
    connect(ui->start_saving_data, &QPushButton::clicked, this, &packets_window::onsavingButtonClicked);

    //Selector de Filtros nuevo
    /*
    connect(ui->bBegin, &QPushButton::clicked,this,&packets_window::onButtonClicked);
    connect(ui->listProtocol,&QListWidget::itemSelectionChanged,this,&packets_window::onCellClicked);
        connect(ui->listDevices,&QListWidget::itemSelectionChanged,this,&packets_window::onCellClicked);
        connect(ui->comboIP, &QComboBox::currentIndexChanged, this, &packets_window::onComboBoxSelectionChanged);
    */
}


packets_window::~packets_window()
{
    delete ui;
}

//propiedades static para facilitar la comunicación entre clases
QList<QString> packets_window::deviceslist;
int packets_window::selectedDeviceIndex;

void packets_window::addPacketToTable(int packetNo, const QString id,
                                      const QString &source, const QString &destination,
                                      const QString &protocol, int length, int opc) {

    QTableWidget *table = ui->table_packets;

    // Insertamos una nueva fila al final de la tabla
    int rowCount = table->rowCount();  // Obtenemos el número actual de filas
    table->insertRow(rowCount);        // Insertamos una nueva fila

    // Creamos un QTableWidgetItem para cada celda
    QTableWidgetItem *packetNoItem = new QTableWidgetItem(QString::number(packetNo));  // Columna 0: No. packet
    QTableWidgetItem *idItem = new QTableWidgetItem(id);                                   // Columna 1: ID
    QTableWidgetItem *sourceItem = new QTableWidgetItem(source);                          // Columna 2: Source
    QTableWidgetItem *destinationItem = new QTableWidgetItem(destination);                // Columna 3: Destination
    QTableWidgetItem *protocolItem = new QTableWidgetItem(protocol);                      // Columna 4: Protocol
    QTableWidgetItem *lengthItem = new QTableWidgetItem(QString::number(length));        // Columna 5: Length

    // Usamos esto para poner colores a los protocolos
    QColor protocolColor;
    if(opc == 4){
        protocolColor = getProtocolColor(protocol, false); // Para IPv4
    }else if (opc == 6){
        protocolColor = getProtocolColor(protocol, true); // Para Ipv6
    }

    packetNoItem->setBackground(QBrush(protocolColor));  // Aplicar el color al protocolo
    idItem->setBackground(QBrush(protocolColor));  // Aplicar el color al protocolo
    sourceItem->setBackground(QBrush(protocolColor));  // Aplicar el color al protocolo
    destinationItem->setBackground(QBrush(protocolColor));  // Aplicar el color al protocolo
    protocolItem->setBackground(QBrush(protocolColor));  // Aplicar el color al protocolo
    lengthItem->setBackground(QBrush(protocolColor));  // Aplicar el color al protocolo


    // Insertamos los items en las celdas correspondientes
    table->setItem(rowCount, 0, packetNoItem);
    table->setItem(rowCount, 1, idItem);
    table->setItem(rowCount, 2, sourceItem);
    table->setItem(rowCount, 3, destinationItem);
    table->setItem(rowCount, 4, protocolItem);
    table->setItem(rowCount, 5, lengthItem);

    //autoscroll
    ui->table_packets->scrollToItem(ui->table_packets->itemAt(0,rowCount),QAbstractItemView::PositionAtTop);
}


void packets_window::addRawPacket(QString hexString) {
    ui->raw_data->setText(hexString);
}

void packets_window::addPacketDetails(QString details){
    ui->structured_data->setText(details);
}

// Creamos una funcion para la parte de los colores
QColor packets_window::getProtocolColor(const QString &protocol, bool isIPv6) {
    // Para IPv6 (ip_nh)
    if (isIPv6) {
        if (protocol == "Reserved") return QColor(169, 169, 169);  // Gris oscuro
        else if (protocol == "ICMP") return QColor(0, 0, 139);      // Azul oscuro
        else if (protocol == "IGMP") return QColor(25, 25, 112);     // Azul muy oscuro
        else if (protocol == "TCP") return QColor(0, 0, 128);        // Azul marino
        else if (protocol == "UDP") return QColor(70, 130, 180);     // Azul acero
        else if (protocol == "ICMPv6") return QColor(0, 0, 139);     // Azul oscuro
        else if (protocol == "Routing Header") return QColor(112, 128, 144);  // Gris azulado
        else if (protocol == "Fragment Header") return QColor(112, 128, 144); // Gris azulado
        else if (protocol == "ESP") return QColor(0, 128, 128);      // Verde azulado oscuro
        else if (protocol == "AH") return QColor(47, 79, 79);        // Gris azulado oscuro
        else return QColor(169, 169, 169);  // Otros protocolos (gris oscuro)
    }
    // Para IPv4 (ip_p)
    else {
        if (protocol == "Reserved") return QColor(169, 169, 169);  // Gris oscuro
        else if (protocol == "ICMP") return QColor(0, 0, 139);      // Azul oscuro
        else if (protocol == "IGMP") return QColor(25, 25, 112);     // Azul muy oscuro
        else if (protocol == "TCP") return QColor(0, 0, 128);        // Azul marino
        else if (protocol == "UDP") return QColor(70, 130, 180);     // Azul acero
        else if (protocol == "IPv6 encapsulado") return QColor(112, 128, 144); // Gris azulado
        else if (protocol == "ESP") return QColor(0, 128, 128);      // Verde azulado oscuro
        else if (protocol == "AH") return QColor(47, 79, 79);        // Gris azulado oscuro
        else if (protocol == "ICMPv6") return QColor(0, 0, 139);     // Azul oscuro
        else if (protocol == "OSPF") return QColor(47, 79, 79);      // Gris azulado oscuro
        else return QColor(169, 169, 169);  // Otros protocolos (gris oscuro)
    }
}


// metodos para eventos
//evento para cuando se seleccione un elemento de la tablaa
void packets_window::onCellClicked(int row, int column) {
    //tomamos la fila de la tabla y obtenemos el numero de paquete
    QTableWidget *table = ui->table_packets;
    QTableWidgetItem *item = table->item(row, 0);
    if (item) {
        int packetNo = item->text().toInt(); // Convertir a número
        emit packetSelected(packetNo);      // Emitir la señal personalizada
    }

}

//evento para poder ingresar datos cuando se requiera una IP
void packets_window::onComboBoxSelectionChanged(){
}

void packets_window::onButtonClicked(){

    QString filter = "";
    switch(ui->select_filter->currentIndex() + 1)
    {
    case 2:
        filter = "tcp";
        break;

    case 3:
        filter = "udp";
        break;

    case 4:
        filter = "ip";
        break;

    case 5:
        filter = "ip6";
        break;

    case 6:
        filter = QString("src host %1").arg(ui->enter_ip->toPlainText());
        break;

    case 7:
        filter = QString("dst host %1").arg(ui->enter_ip->toPlainText());
        break;

    case 8:
        filter = QString("net %1").arg(ui->enter_ip->toPlainText());
        break;

    }

    //emitimos la señal para que la capture en la ranura la clase
    emit filter_applied(filter);
}


void packets_window::on_listDevices_itemSelectionChanged()
{
    // Obtenemos el índice del elemento seleccionado
    int selected = ui->listDevices->currentRow();

    // Guardamos el índice seleccionado
    selectedDeviceIndex = selected;

    // Deshabilitamos el listWidget para evitar futuras selecciones
    ui->listDevices->setEnabled(false);

    // Emitimos la señal o realizamos acciones necesarias con el índice seleccionado
    emit start_capturing();
}


void packets_window::on_listProtocol_itemSelectionChanged()
{
    QString filter="";
    switch(ui->listProtocol->currentRow()){
    case 0:
        filter="";
        //codigo provisional para bloquear moverle de más a los filtros
        ui->txtIPDest->setReadOnly(false);
        ui->txtIPSource->setReadOnly(false);
        ui->txtIPSubnet->setReadOnly(false);
        ui->checkIPSource->setCheckable(true);
        ui->checkIPSubnet->setCheckable(true);
        ui->checkIPDest->setCheckable(true);
        ui->comboIP->setHidden(false);
        break;
    case 1:
        filter="tcp";
        //codigo provisional para bloquear moverle de más a los filtros
        ui->txtIPDest->setReadOnly(true);
        ui->txtIPSource->setReadOnly(true);
        ui->txtIPSubnet->setReadOnly(true);
        ui->checkIPSource->setCheckable(false);
        ui->checkIPSubnet->setCheckable(false);
        ui->checkIPDest->setCheckable(false);
        ui->comboIP->setHidden(true);
        break;
    case 2:
        filter="udp";
        //codigo provisional para bloquear moverle de más a los filtros
        ui->txtIPDest->setReadOnly(true);
        ui->txtIPSource->setReadOnly(true);
        ui->txtIPSubnet->setReadOnly(true);
        ui->checkIPSource->setCheckable(false);
        ui->checkIPSubnet->setCheckable(false);
        ui->checkIPDest->setCheckable(false);
        ui->comboIP->setHidden(true);
        break;
    case 3: break;
        filter="icmp";
        //codigo provisional para bloquear moverle de más a los filtros
        ui->txtIPDest->setReadOnly(true);
        ui->txtIPSource->setReadOnly(true);
        ui->txtIPSubnet->setReadOnly(true);
        ui->checkIPSource->setCheckable(false);
        ui->checkIPSubnet->setCheckable(false);
        ui->checkIPDest->setCheckable(false);
        ui->comboIP->setHidden(true);
    default:
        filter="";
        break;
    }


    //salida
    emit filter_applied(filter);

}


void packets_window::on_comboIP_activated(int index)
{
    QString filter="";
    switch(index){
    case 0:
        ui->txtIPDest->setReadOnly(false);
        ui->txtIPSource->setReadOnly(false);
        ui->txtIPSubnet->setReadOnly(false);
        ui->checkIPSource->setCheckable(true);
        ui->checkIPSubnet->setCheckable(true);
        ui->checkIPDest->setCheckable(true);
        break;
    case 1:
        filter = "ip";
        //provisional
        ui->txtIPDest->setReadOnly(true);
        ui->txtIPSource->setReadOnly(true);
        ui->txtIPSubnet->setReadOnly(true);
        ui->checkIPSource->setCheckable(false);
        ui->checkIPSubnet->setCheckable(false);
        ui->checkIPDest->setCheckable(false);
        //ui->listProtocol->
        break;
    case 2:
        filter = "ip6";
        //provisional
        ui->txtIPDest->setReadOnly(true);
        ui->txtIPSource->setReadOnly(true);
        ui->txtIPSubnet->setReadOnly(true);
        ui->checkIPSource->setCheckable(false);
        ui->checkIPSubnet->setCheckable(false);
        ui->checkIPDest->setCheckable(false);
        break;

   // case 3:

     //   break;

    default:
        filter="";
        break;
    }

    emit filter_applied(filter);
}






void packets_window::on_checkIPSource_stateChanged(int arg1)
{
    QString filter="";
    qDebug()<<arg1;
    switch(arg1){
    case 0:
        filter="";
        ui->txtIPDest->setReadOnly(false);
        ui->checkIPDest->setCheckable(true);
        ui->txtIPSubnet->setReadOnly(false);
        ui->checkIPSubnet->setCheckable(true);
        break;
    case 2:
        //applying ip source filter
        filter = QString("src host %1").arg(ui->txtIPSource->text());
        ui->txtIPDest->setReadOnly(true);
        ui->checkIPDest->setCheckable(false);
        ui->txtIPSubnet->setReadOnly(true);
        ui->checkIPSubnet->setCheckable(false);
        break;
    }

    emit filter_applied(filter);
}


void packets_window::on_checkIPDest_stateChanged(int arg1)
{
    QString filter="";
    qDebug()<<arg1;
    switch(arg1){
    case 0:
        filter="";
        ui->txtIPSource->setReadOnly(false);
        ui->checkIPSource->setCheckable(true);
        ui->txtIPSubnet->setReadOnly(false);
        ui->checkIPSubnet->setCheckable(true);
        break;
    case 2:
        //applying ip source filter
        filter = QString("dst host %1").arg(ui->txtIPDest->text());
        ui->txtIPSource->setReadOnly(true);
        ui->checkIPSource->setCheckable(false);
        ui->txtIPSubnet->setReadOnly(true);
        ui->checkIPSubnet->setCheckable(false);
        break;
    }

    emit filter_applied(filter);
}


void packets_window::on_checkIPSubnet_stateChanged(int arg1)
{
    QString filter="";
    qDebug()<<arg1;
    switch(arg1){
    case 0:
        filter="";
        ui->txtIPSource->setReadOnly(false);
        ui->checkIPSource->setCheckable(true);
        ui->txtIPDest->setReadOnly(false);
        ui->checkIPDest->setCheckable(true);
        break;
    case 2:
        //applying ip source filter
        filter = QString("net %1").arg(ui->txtIPSubnet->text());
        ui->txtIPSource->setReadOnly(true);
        ui->checkIPSource->setCheckable(false);
        ui->txtIPDest->setReadOnly(true);
        ui->checkIPDest->setCheckable(false);
        break;
    }

    emit filter_applied(filter);
}

void packets_window::on_bBegin_clicked()
{
    ui->tabWidget->setCurrentIndex(1);
}

void packets_window::fillDeviceList(){
    //limpiamos y agregamos de nuevo
    if (ui->listDevices) {
        ui->listDevices->clear();

        for (int i = 0; i < deviceslist.size(); i++) {
            ui->listDevices->addItem(deviceslist.at(i));
        }
    }
}


void packets_window::on_pushButton_clicked()
{
    fillDeviceList();
}


//para el boton start_saving_data
void packets_window::onsavingButtonClicked() {
    // Alternar el estado de guardado
    static bool savingInProgress = false;

    if (savingInProgress) {
        // Si el guardado está en progreso, detenemos el guardado
        savingInProgress = false;
        ui->start_saving_data->setText("Start Saving Data"); // Cambiar el texto a "Start Saving Data"
        emit saving_applied(false); // Detener el guardado
    } else {
        // Si el guardado no está en progreso, iniciamos el guardado
        savingInProgress = true;
        ui->start_saving_data->setText("Stop Saving Data"); // Cambiar el texto a "Stop Saving Data"
        emit saving_applied(true); // Iniciar el guardado
    }
}


//implementamos el metodo sobrescrito (closeEvent) para cuando se cierre la ventana
//este preguntara si se quiere guardar los datos

void packets_window::closeEvent(QCloseEvent *event)
{
    // Preguntar si el usuario desea guardar los datos antes de cerrar
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Save Data", "Do you wish to save the data?",
                                  QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);

    if (reply == QMessageBox::Yes) {
        saveAllPackets();
        event->accept();
    } else if (reply == QMessageBox::No) {
        event->accept();
    } else {
        event->ignore();
    }
}



#include <QFileDialog> // Necesario para el QFileDialog

void packets_window::saveAllPackets() {
    // Verifica si la lista de paquetes no está vacía
    if (list_packets->isEmpty()) {
        qDebug() << "No packets to save.";
        return;
    }

    // Abre un diálogo para que el usuario elija la ubicación del archivo
    QString currentDateTime = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
    QString suggestedFileName = "all_packets_saved_" + currentDateTime + ".csv";

    QString fileName = QFileDialog::getSaveFileName(
        this, // Parent widget
        "Guardar archivo CSV", // Título del diálogo
        QDir::homePath() + "/" + suggestedFileName, // Ruta y nombre sugerido
        "Archivos CSV (*.csv)" // Filtro de archivos
        );

    // Si el usuario canceló el diálogo, salimos
    if (fileName.isEmpty()) {
        qDebug() << "Save operation cancelled.";
        return;
    }

    // Crear el archivo con la ruta seleccionada por el usuario
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Error opening file for writing.";
        return;
    }

    QTextStream csvStream(&file);

    // Escribir los encabezados del archivo CSV
    csvStream << "Packet ID,Source,Destination,Protocol,Length,Raw Data\n";

    // Recorre todos los paquetes en la lista usando un índice
    for (int i = 0; i < list_packets->size(); ++i) {
        Packet* packet = list_packets->at(i);

        QString src, dst, protocol;

        if (packet->getOpc() == 4) { // IPv4
            src = packet->getIPv4Source();
            dst = packet->getIPv4Destination();
            protocol = "IPv4";
        } else if (packet->getOpc() == 6) { // IPv6
            src = packet->getIPv6Source();
            dst = packet->getIPv6Destination();
            protocol = "IPv6";
        }

        // Escribir los datos del paquete en el archivo CSV
        csvStream << packet->getId() << ","
                  << src << ","
                  << dst << ","
                  << protocol << ","
                  << packet->getSize_packet() << ","
                  << packet->getRawDataCSV() << "\n";
    }

    // Cerrar el archivo después de escribir
    file.close();

    qDebug() << "File saved successfully at:" << fileName;
}
