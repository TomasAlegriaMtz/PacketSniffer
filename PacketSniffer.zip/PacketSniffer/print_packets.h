#ifndef PRINT_PACKETS_H
#define PRINT_PACKETS_H

#include <QThread>
#include <QList>
#include <QMutex>
#include "packet.h"
#include "packets_window.h"

class print_packets : public QThread
{
    Q_OBJECT

public:
    explicit print_packets(QList<Packet *> *packetList, packets_window *window, QMutex *mtx);

protected:
    void run() override;

private slots:
    void onPacketSelected(int ); // Slot para manejar la señal de paquetes seleccionados

private:
    QList<Packet *> *list_packets;  // Puntero a la lista de paquetes
    QList<Packet *> *aux;
    packets_window *window;  // Puntero a la ventana
    QMutex *mutex;  // Puntero al mutex para sincronización
};

#endif // PRINT_PACKETS_H
