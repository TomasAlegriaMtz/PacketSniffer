#include "print_packets.h"
#include "packets_window.h"
#include <QMutexLocker>
#include <QThread>
#include <QDebug>

print_packets::print_packets(QList<Packet *> *packetList, packets_window *window, QMutex *mtx)
    : list_packets(packetList), window(window), mutex(mtx)
{
    this->aux = list_packets;
    // Conectar la señal de packets_window al slot onPacketSelected
    connect(window, &packets_window::packetSelected, this, &print_packets::onPacketSelected);
}

void print_packets::run()
{
    Packet* lastProcessedPacket = nullptr;  // Mantener un puntero al último paquete procesado para solo añadir al final

    while (true) {
        QMutexLocker locker(mutex);  // Bloquear el mutex automáticamente para proteger el acceso a la lista

        // Si hay un paquete nuevo, agregarlo a la lista y procesarlo
        for (int i = lastProcessedPacket ? list_packets->indexOf(lastProcessedPacket) + 1 : 0;
             i < list_packets->size(); ++i) {
            Packet* packet = list_packets->at(i);  // Acceder al paquete por índice
            int packetNo = packet->getId();

            // Extraer los datos del paquete
            QString id = packet->getIPv4Identification();
            int length = packet->getSize_packet();
            QString source;
            QString destination;
            QString protocol;

            if (packet->getOpc() == 4) {  // Si es IPv4
                source = packet->getIPv4Source();
                destination = packet->getIPv4Destination();
                protocol = packet->getIPv4Protocol();
            } else if (packet->getOpc() == 6) {  // Si es IPv6
                source = packet->getIPv6Source();
                destination = packet->getIPv6Destination();
                protocol = packet->getIPv6Protocol();
            }

            // Agregar el paquete a la tabla solo si es nuevo
            window->addPacketToTable(packetNo, id, source,
                                     destination, protocol, length, packet->opc);

            // Actualizar el último paquete procesado
            lastProcessedPacket = packet;
        }

        locker.unlock();  // Liberar el mutex después de procesar la lista
    }
}

void print_packets::onPacketSelected(int packetNo)
{
    // Este slot se ejecuta cuando se selecciona un paquete en packets_window
    qDebug() << "Paquete seleccionado en packets_window:" << packetNo;

    //Aqui ya seleccionado el paquete, lo buscamos en la lista y mostramos el raw data
    Packet *pack = aux->at(packetNo - 1);

    //obtenemos los datos en crudo y los enviamos a el metodo de window para que lo convierta en QString
    // y lo muestre en la pantalla
    window->addRawPacket(pack->getRawDataHex());
    window->addPacketDetails(pack->getPacketDetails());
}
